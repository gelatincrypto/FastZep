namespace LipingShare.LCLib.Asn1Processor
{
    using System;
    using System.IO;
    using System.Windows.Forms;

    [Serializable]
    public class Asn1ClipboardData
    {
        private static string asn1FormatName = "Asn1NodeDataFormat";

        public static void Copy(Asn1Node node)
        {
            DataFormats.GetFormat(asn1FormatName);
            MemoryStream xdata = new MemoryStream();
            node.SaveData(xdata);
            xdata.Position = 0L;
            byte[] buffer = new byte[xdata.Length];
            xdata.Read(buffer, 0, (int) xdata.Length);
            xdata.Close();
            DataObject data = new DataObject();
            data.SetData(asn1FormatName, buffer);
            data.SetData(DataFormats.Text, Asn1Util.FormatString(Asn1Util.ToHexString(buffer), 0x20, 2));
            Clipboard.SetDataObject(data, true);
        }

        public static bool IsDataReady()
        {
            bool flag = false;
            try
            {
                IDataObject dataObject = Clipboard.GetDataObject();
                if (((byte[]) dataObject.GetData(asn1FormatName)) != null)
                {
                    return true;
                }
                string data = (string) dataObject.GetData(DataFormats.Text);
                if (Asn1Util.IsAsn1EncodedHexStr(data))
                {
                    flag = true;
                }
            }
            catch
            {
                flag = false;
            }
            return flag;
        }

        public static Asn1Node Paste()
        {
            DataFormats.GetFormat(asn1FormatName);
            Asn1Node node = new Asn1Node();
            IDataObject dataObject = Clipboard.GetDataObject();
            byte[] data = (byte[]) dataObject.GetData(asn1FormatName);
            if (data != null)
            {
                MemoryStream xdata = new MemoryStream(data);
                xdata.Position = 0L;
                node.LoadData(xdata);
                return node;
            }
            string dataStr = (string) dataObject.GetData(DataFormats.Text);
            new Asn1Node();
            if (Asn1Util.IsAsn1EncodedHexStr(dataStr))
            {
                byte[] byteData = Asn1Util.HexStrToBytes(dataStr);
                node.LoadData(byteData);
            }
            return node;
        }
    }
}


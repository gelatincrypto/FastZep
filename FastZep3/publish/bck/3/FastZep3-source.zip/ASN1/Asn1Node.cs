namespace LipingShare.LCLib.Asn1Processor
{
    using System;
    using System.Collections;
    using System.IO;
    using System.Text;

    public class Asn1Node : IAsn1Node
    {
        public const int BitStringUnusedFiledLength = 1;
        private byte[] data;
        private long dataLength;
        private long dataOffset;
        private long deepness;
        public const int defaultLineLen = 80;
        private ArrayList childNodeList;
        private const int indentStep = 3;
        private bool isIndefiniteLength;
        private long lengthFieldBytes;
        public const int minLineLen = 60;
        private Asn1Node parentNode;
        private bool parseEncapsulatedData;
        private string path;
        private bool requireRecalculatePar;
        private byte tag;
        public const int TagLength = 1;
        private byte unusedBits;

        public Asn1Node()
        {
            this.path = "";
            this.requireRecalculatePar = true;
            this.parseEncapsulatedData = true;
            this.Init();
            this.dataOffset = 0L;
        }
        // Added by LS
        private void BasicInit() {

            this.path = "";
            this.requireRecalculatePar = true;
            this.parseEncapsulatedData = true;
            this.Init();
            this.dataOffset = 0L;
        }
        // Added by LS
        public Asn1Node(int data)
        {
            BasicInit();
            byte[] b = BitConverter.GetBytes(data);
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(b);
            }
            this.Data = b;
            this.GetLabel(Asn1Tag.INTEGER);
        }
        // Added by LS
        public Asn1Node(byte[] data, uint type)
        {
            BasicInit();
            this.Data = data;
            this.GetLabel(type);
        }
        // Added by LS
        public Asn1Node(byte[] data)
        {
            BasicInit();
            this.Data = data;
            this.GetLabel(Asn1Tag.BIT_STRING);
        }
        // Added by LS
        public Asn1Node(uint type)
        {
            BasicInit();
            this.GetLabel(type);
        }
        


        private Asn1Node(Asn1Node parentNode, long dataOffset)
        {
            this.path = "";
            this.requireRecalculatePar = true;
            this.parseEncapsulatedData = true;
            this.Init();
            this.deepness = parentNode.Deepness + 1L;
            this.parentNode = parentNode;
            this.dataOffset = dataOffset;
        }

        public void AddChild(Asn1Node xdata)
        {
            this.childNodeList.Add(xdata);
            this.RecalculateTreePar();
        }

        public void ClearAll()
        {
            this.data = null;
            for (int i = 0; i < this.childNodeList.Count; i++)
            {
                ((Asn1Node) this.childNodeList[i]).ClearAll();
            }
            this.childNodeList.Clear();
            this.RecalculateTreePar();
        }

        public Asn1Node Clone()
        {
            MemoryStream xdata = new MemoryStream();
            this.SaveData(xdata);
            xdata.Position = 0L;
            Asn1Node node = new Asn1Node();
            node.LoadData(xdata);
            return node;
        }

        private string FormatLineHexString(string lStr, int indent, int lineLen, string msg)
        {
            string str = "";
            indent += 3;
            int length = lineLen - indent;
            int len = indent;
            for (int i = 0; i < msg.Length; i += length)
            {
                if ((i + length) > msg.Length)
                {
                    string str2 = str;
                    str = str2 + "\r\n" + lStr + Asn1Util.GenStr(len, ' ') + msg.Substring(i, msg.Length - i);
                }
                else
                {
                    string str3 = str;
                    str = str3 + "\r\n" + lStr + Asn1Util.GenStr(len, ' ') + msg.Substring(i, length);
                }
            }
            return str;
        }

        private string FormatLineString(string lStr, int indent, int lineLen, string msg)
        {
            string str = "";
            indent += 3;
            int length = lineLen - indent;
            int len = indent;
            for (int i = 0; i < msg.Length; i += length)
            {
                if ((i + length) > msg.Length)
                {
                    string str2 = str;
                    str = str2 + "\r\n" + lStr + Asn1Util.GenStr(len, ' ') + "'" + msg.Substring(i, msg.Length - i) + "'";
                }
                else
                {
                    string str3 = str;
                    str = str3 + "\r\n" + lStr + Asn1Util.GenStr(len, ' ') + "'" + msg.Substring(i, length) + "'";
                }
            }
            return str;
        }

        protected bool GeneralDecode(Stream xdata)
        {
            bool flag = false;
            long num = xdata.Length - xdata.Position;
            this.tag = (byte) xdata.ReadByte();
            long position = xdata.Position;
            this.dataLength = Asn1Util.DerLengthDecode(xdata, ref this.isIndefiniteLength);
            if (this.dataLength < 0L)
            {
                return flag;
            }
            long num3 = xdata.Position;
            this.lengthFieldBytes = num3 - position;
            if (num < ((this.dataLength + 1L) + this.lengthFieldBytes))
            {
                return flag;
            }
            if (((this.ParentNode == null) || ((this.ParentNode.tag & 0x20) == 0)) && (((this.tag & 0x1f) <= 0) || ((this.tag & 0x1f) > 30)))
            {
                return flag;
            }
            if (this.tag == 3)
            {
                if (this.dataLength < 1L)
                {
                    return flag;
                }
                this.unusedBits = (byte) xdata.ReadByte();
                this.data = new byte[this.dataLength - 1L];
                xdata.Read(this.data, 0, (int) (this.dataLength - 1L));
            }
            else
            {
                this.data = new byte[this.dataLength];
                xdata.Read(this.data, 0, (int) this.dataLength);
            }
            return true;
        }

        public string GetDataStr(bool pureHexMode)
        {
            if (!pureHexMode)
            {
                switch (this.tag)
                {
                    case 2:
                        return Asn1Util.FormatString(Asn1Util.ToHexString(this.data), 0x20, 2);

                    case 3:
                        return Asn1Util.FormatString(Asn1Util.ToHexString(this.data), 0x20, 2);

                    case 6:
                    {
                        Oid oid = new Oid();
                        return oid.Decode(new MemoryStream(this.data));
                    }
                    case 12:
                    {
                        UTF8Encoding encoding = new UTF8Encoding();
                        return encoding.GetString(this.data);
                    }
                    case 13:
                    {
                        RelativeOid oid2 = new RelativeOid();
                        return oid2.Decode(new MemoryStream(this.data));
                    }
                    case 0x12:
                    case 0x13:
                    case 0x16:
                    case 0x17:
                    case 0x18:
                    case 0x1a:
                    case 0x1b:
                    case 0x1c:
                    case 30:
                        return Asn1Util.BytesToString(this.data);
                }
                if (((this.tag & 0x1f) == 6) || Asn1Util.IsAsciiString(this.Data))
                {
                    return Asn1Util.BytesToString(this.data);
                }
            }
            return Asn1Util.FormatString(Asn1Util.ToHexString(this.data), 0x20, 2);
        }

        public static Asn1Node GetDecendantNodeByOid(string oid, Asn1Node startNode)
        {
            Asn1Node decendantNodeByOid = null;
            Oid oid2 = new Oid();
            for (int i = 0; i < startNode.ChildNodeCount; i++)
            {
                Asn1Node childNode = startNode.GetChildNode(i);
                int num2 = childNode.tag & 0x1f;
                if ((num2 == 6) && (oid == oid2.Decode(childNode.Data)))
                {
                    return childNode;
                }
                decendantNodeByOid = GetDecendantNodeByOid(oid, childNode);
                if (decendantNodeByOid != null)
                {
                    return decendantNodeByOid;
                }
            }
            return decendantNodeByOid;
        }

        public Asn1Node GetDescendantNodeByPath(string nodePath)
        {
            Asn1Node childNode = this;
            if (nodePath != null)
            {
                nodePath = nodePath.TrimEnd(new char[0]).TrimStart(new char[0]);
                if (nodePath.Length < 1)
                {
                    return childNode;
                }
                string[] strArray = nodePath.Split(new char[] { '/' });
                try
                {
                    for (int i = 1; i < strArray.Length; i++)
                    {
                        childNode = childNode.GetChildNode(Convert.ToInt32(strArray[i]));
                    }
                }
                catch
                {
                    childNode = null;
                }
            }
            return childNode;
        }

        public static long GetDescendantNodeCount(Asn1Node node)
        {
            long num = 0L;
            num += node.ChildNodeCount;
            for (int i = 0; i < node.ChildNodeCount; i++)
            {
                num += GetDescendantNodeCount(node.GetChildNode(i));
            }
            return num;
        }

        private string GetHexPrintingStr(Asn1Node startNode, string baseLine, string lStr, int lineLen)
        {
            string str = "";
            string indentStr = this.GetIndentStr(startNode);
            string msg = Asn1Util.ToHexString(this.data);
            if (msg.Length > 0)
            {
                if ((baseLine.Length + msg.Length) < lineLen)
                {
                    string str4 = str;
                    str = str4 + baseLine + "'" + msg + "'";
                }
                else
                {
                    str = str + baseLine + this.FormatLineHexString(lStr, indentStr.Length, lineLen, msg);
                }
            }
            else
            {
                str = str + baseLine;
            }
            return (str + "\r\n");
        }

        public Asn1Node GetChildNode(int index)
        {
            Asn1Node node = null;
            if (index < this.ChildNodeCount)
            {
                node = (Asn1Node) this.childNodeList[index];
            }
            return node;
        }

        protected string GetIndentStr(Asn1Node startNode)
        {
            string str = "";
            long deepness = 0L;
            if (startNode != null)
            {
                deepness = startNode.Deepness;
            }
            for (long i = 0L; i < (this.deepness - deepness); i += 1L)
            {
                str = str + "   ";
            }
            return str;
        }

        public string GetLabel(uint mask)
        {
            string str4;
            string oidName;
            string str = "";
            string str2 = "";
            string str3 = "";
            if ((mask & 4) != 0)
            {
                if ((mask & 8) != 0)
                {
                    str3 = string.Format("(0x{0:X2},0x{1:X6},0x{2:X4})", this.tag, this.dataOffset, this.dataLength);
                }
                else
                {
                    str3 = string.Format("(0x{0:X6},0x{1:X4})", this.dataOffset, this.dataLength);
                }
            }
            else if ((mask & 8) != 0)
            {
                str3 = string.Format("({0},{1},{2})", this.tag, this.dataOffset, this.dataLength);
            }
            else
            {
                str3 = string.Format("({0},{1})", this.dataOffset, this.dataLength);
            }
            switch (this.tag)
            {
                case 2:
                    if ((mask & 1) != 0)
                    {
                        str = str + str3;
                    }
                    str = str + " " + this.TagName;
                    if ((mask & 2) != 0)
                    {
                        if ((this.data != null) && (this.dataLength < 8L))
                        {
                            str2 = Asn1Util.BytesToLong(this.data).ToString();
                        }
                        else
                        {
                            str2 = Asn1Util.ToHexString(this.data);
                        }
                        str = str + ((str2.Length > 0) ? (" : '" + str2 + "'") : "");
                    }
                    break;

                case 3:
                {
                    if ((mask & 1) != 0)
                    {
                        str = str + str3;
                    }
                    string str6 = str;
                    str = str6 + " " + this.TagName + " UnusedBits: " + this.unusedBits.ToString();
                    if ((mask & 2) != 0)
                    {
                        str2 = Asn1Util.ToHexString(this.data);
                        str = str + ((str2.Length > 0) ? (" : '" + str2 + "'") : "");
                    }
                    break;
                }
                case 6:
                {
                    Oid oid = new Oid();
                    str4 = oid.Decode(this.data);
                    oidName = oid.GetOidName(str4);
                    if ((mask & 1) != 0)
                    {
                        str = str + str3;
                    }
                    str = (str + " " + this.TagName) + " : " + oidName;
                    if ((mask & 2) != 0)
                    {
                        str = str + ((str4.Length > 0) ? (" : '" + str4 + "'") : "");
                    }
                    break;
                }
                case 12:
                case 0x12:
                case 0x13:
                case 0x16:
                case 0x17:
                case 0x18:
                case 0x1a:
                case 0x1b:
                case 0x1c:
                case 30:
                    if ((mask & 1) != 0)
                    {
                        str = str + str3;
                    }
                    str = str + " " + this.TagName;
                    if ((mask & 2) != 0)
                    {
                        if (this.tag == 12)
                        {
                            str2 = new UTF8Encoding().GetString(this.data);
                        }
                        else
                        {
                            str2 = Asn1Util.BytesToString(this.data);
                        }
                        str = str + ((str2.Length > 0) ? (" : '" + str2 + "'") : "");
                    }
                    break;

                case 13:
                    str4 = new RelativeOid().Decode(this.data);
                    oidName = "";
                    if ((mask & 1) != 0)
                    {
                        str = str + str3;
                    }
                    str = (str + " " + this.TagName) + " : " + oidName;
                    if ((mask & 2) != 0)
                    {
                        str = str + ((str4.Length > 0) ? (" : '" + str4 + "'") : "");
                    }
                    break;

                default:
                    if ((mask & 1) != 0)
                    {
                        str = str + str3;
                    }
                    str = str + " " + this.TagName;
                    if ((mask & 2) != 0)
                    {
                        if (((this.tag & 0x1f) == 6) || Asn1Util.IsAsciiString(this.Data))
                        {
                            str2 = Asn1Util.BytesToString(this.data);
                        }
                        else
                        {
                            str2 = Asn1Util.ToHexString(this.data);
                        }
                        str = str + ((str2.Length > 0) ? (" : '" + str2 + "'") : "");
                    }
                    break;
            }
            if ((mask & 0x10) != 0)
            {
                str = "(" + this.path + ") " + str;
            }
            return str;
        }

        protected string GetListStr(Asn1Node startNode, int lineLen)
        {
            string str = "";
            for (int i = 0; i < this.childNodeList.Count; i++)
            {
                Asn1Node node = (Asn1Node) this.childNodeList[i];
                str = str + node.GetText(startNode, lineLen);
            }
            return str;
        }

        public byte[] GetRawData()
        {
            MemoryStream xdata = new MemoryStream();
            this.SaveData(xdata);
            byte[] buffer = new byte[xdata.Length];
            xdata.Position = 0L;
            xdata.Read(buffer, 0, (int) xdata.Length);
            xdata.Close();
            return buffer;
        }

        public string GetText(Asn1Node startNode, int lineLen)
        {
            string str4;
            string oidName;
            string str = "";
            string baseLine = "";
            string msg = "";
            switch (this.tag)
            {
                case 2:
                    if ((this.data == null) || (this.dataLength >= 8L))
                    {
                        baseLine = string.Format("{0,6}|{1,6}|{2,7}|{3} {4} : ", new object[] { this.dataOffset, this.dataLength, this.lengthFieldBytes, this.GetIndentStr(startNode), this.TagName });
                        str = str + this.GetHexPrintingStr(startNode, baseLine, "      |      |       | ", lineLen);
                    }
                    else
                    {
                        str = str + string.Format("{0,6}|{1,6}|{2,7}|{3} {4} : {5}\r\n", new object[] { this.dataOffset, this.dataLength, this.lengthFieldBytes, this.GetIndentStr(startNode), this.TagName, Asn1Util.BytesToLong(this.data).ToString() });
                    }
                    goto Label_060E;

                case 3:
                    baseLine = string.Format("{0,6}|{1,6}|{2,7}|{3} {4} UnusedBits:{5} : ", new object[] { this.dataOffset, this.dataLength, this.lengthFieldBytes, this.GetIndentStr(startNode), this.TagName, this.unusedBits });
                    msg = Asn1Util.ToHexString(this.data);
                    if ((baseLine.Length + msg.Length) >= lineLen)
                    {
                        str = str + baseLine + this.FormatLineHexString("      |      |       | ", this.GetIndentStr(startNode).Length, lineLen, msg + "\r\n");
                    }
                    else if (msg.Length >= 1)
                    {
                        string str6 = str;
                        str = str6 + baseLine + "'" + msg + "'\r\n";
                    }
                    else
                    {
                        str = str + baseLine + "\r\n";
                    }
                    goto Label_060E;

                case 6:
                {
                    Oid oid = new Oid();
                    str4 = oid.Decode(new MemoryStream(this.data));
                    oidName = oid.GetOidName(str4);
                    str = str + string.Format("{0,6}|{1,6}|{2,7}|{3} {4} : {5} [{6}]\r\n", new object[] { this.dataOffset, this.dataLength, this.lengthFieldBytes, this.GetIndentStr(startNode), this.TagName, oidName, str4 });
                    goto Label_060E;
                }
                case 12:
                case 0x12:
                case 0x13:
                case 0x16:
                case 0x17:
                case 0x18:
                case 0x1a:
                case 0x1b:
                case 0x1c:
                case 30:
                    baseLine = string.Format("{0,6}|{1,6}|{2,7}|{3} {4} : ", new object[] { this.dataOffset, this.dataLength, this.lengthFieldBytes, this.GetIndentStr(startNode), this.TagName });
                    if (this.tag != 12)
                    {
                        msg = Asn1Util.BytesToString(this.data);
                        break;
                    }
                    msg = new UTF8Encoding().GetString(this.data);
                    break;

                case 13:
                    str4 = new RelativeOid().Decode(new MemoryStream(this.data));
                    oidName = "";
                    str = str + string.Format("{0,6}|{1,6}|{2,7}|{3} {4} : {5} [{6}]\r\n", new object[] { this.dataOffset, this.dataLength, this.lengthFieldBytes, this.GetIndentStr(startNode), this.TagName, oidName, str4 });
                    goto Label_060E;

                default:
                    if (((this.tag & 0x1f) == 6) || Asn1Util.IsAsciiString(this.Data))
                    {
                        baseLine = string.Format("{0,6}|{1,6}|{2,7}|{3} {4} : ", new object[] { this.dataOffset, this.dataLength, this.lengthFieldBytes, this.GetIndentStr(startNode), this.TagName });
                        msg = Asn1Util.BytesToString(this.data);
                        if ((baseLine.Length + msg.Length) < lineLen)
                        {
                            string str8 = str;
                            str = str8 + baseLine + "'" + msg + "'\r\n";
                        }
                        else
                        {
                            str = str + baseLine + this.FormatLineString("      |      |       | ", this.GetIndentStr(startNode).Length, lineLen, msg) + "\r\n";
                        }
                    }
                    else
                    {
                        baseLine = string.Format("{0,6}|{1,6}|{2,7}|{3} {4} : ", new object[] { this.dataOffset, this.dataLength, this.lengthFieldBytes, this.GetIndentStr(startNode), this.TagName });
                        str = str + this.GetHexPrintingStr(startNode, baseLine, "      |      |       | ", lineLen);
                    }
                    goto Label_060E;
            }
            if ((baseLine.Length + msg.Length) < lineLen)
            {
                string str7 = str;
                str = str7 + baseLine + "'" + msg + "'\r\n";
            }
            else
            {
                str = str + baseLine + this.FormatLineString("      |      |       | ", this.GetIndentStr(startNode).Length, lineLen, msg) + "\r\n";
            }
        Label_060E:
            if (this.childNodeList.Count >= 0)
            {
                str = str + this.GetListStr(startNode, lineLen);
            }
            return str;
        }

        private void Init()
        {
            this.childNodeList = new ArrayList();
            this.data = null;
            this.dataLength = 0L;
            this.lengthFieldBytes = 0L;
            this.unusedBits = 0;
            this.tag = 0x30;
            this.childNodeList.Clear();
            this.deepness = 0L;
            this.parentNode = null;
        }

        public int InsertChild(Asn1Node xdata, Asn1Node indexNode)
        {
            int index = this.childNodeList.IndexOf(indexNode);
            this.childNodeList.Insert(index, xdata);
            this.RecalculateTreePar();
            return index;
        }

        public int InsertChild(Asn1Node xdata, int index)
        {
            this.childNodeList.Insert(index, xdata);
            this.RecalculateTreePar();
            return index;
        }

        public int InsertChildAfter(Asn1Node xdata, Asn1Node indexNode)
        {
            int index = this.childNodeList.IndexOf(indexNode) + 1;
            this.childNodeList.Insert(index, xdata);
            this.RecalculateTreePar();
            return index;
        }

        public int InsertChildAfter(Asn1Node xdata, int index)
        {
            int num = index + 1;
            this.childNodeList.Insert(num, xdata);
            this.RecalculateTreePar();
            return num;
        }

        protected bool InternalLoadData(Stream xdata)
        {
            bool flag = true;
            this.ClearAll();
            long position = xdata.Position;
            byte num = (byte) xdata.ReadByte();
            xdata.Position = position;
            int num3 = num & 0x1f;
            if (((num & 0x20) != 0) || (this.parseEncapsulatedData && (((((num3 == 3) || (num3 == 8)) || ((num3 == 0x1b) || (num3 == 0x18))) || (((num3 == 0x19) || (num3 == 0x16)) || ((num3 == 4) || (num3 == 0x13)))) || ((((num3 == 0x10) || (num3 == 0x11)) || ((num3 == 20) || (num3 == 0x1c))) || (((num3 == 12) || (num3 == 0x15)) || (num3 == 0x1a))))))
            {
                if (!this.ListDecode(xdata) && !this.GeneralDecode(xdata))
                {
                    flag = false;
                }
                return flag;
            }
            if (!this.GeneralDecode(xdata))
            {
                flag = false;
            }
            return flag;
        }

        protected bool ListDecode(Stream xdata)
        {
            bool flag = false;
            long position = xdata.Position;
            try
            {
                long num2 = xdata.Length - xdata.Position;
                this.tag = (byte) xdata.ReadByte();
                long num3 = xdata.Position;
                this.dataLength = Asn1Util.DerLengthDecode(xdata, ref this.isIndefiniteLength);
                if ((this.dataLength < 0L) || (num2 < this.dataLength))
                {
                    return flag;
                }
                long num4 = xdata.Position;
                this.lengthFieldBytes = num4 - num3;
                long dataOffset = (this.dataOffset + 1L) + this.lengthFieldBytes;
                if (this.tag == 3)
                {
                    this.unusedBits = (byte) xdata.ReadByte();
                    this.dataLength -= 1L;
                    dataOffset += 1L;
                }
                if (this.dataLength <= 0L)
                {
                    return flag;
                }
                Stream stream = new MemoryStream((int) this.dataLength);
                byte[] buffer = new byte[this.dataLength];
                xdata.Read(buffer, 0, (int) this.dataLength);
                if (this.tag == 3)
                {
                    this.dataLength += 1L;
                }
                stream.Write(buffer, 0, buffer.Length);
                stream.Position = 0L;
                while (stream.Position < stream.Length)
                {
                    Asn1Node node = new Asn1Node(this, dataOffset);
                    node.parseEncapsulatedData = this.parseEncapsulatedData;
                    num3 = stream.Position;
                    if (!node.InternalLoadData(stream))
                    {
                        return flag;
                    }
                    this.AddChild(node);
                    num4 = stream.Position;
                    dataOffset += num4 - num3;
                }
                flag = true;
            }
            finally
            {
                if (!flag)
                {
                    xdata.Position = position;
                    this.ClearAll();
                }
            }
            return flag;
        }

        public bool LoadData(Stream xdata)
        {
            bool flag2;
            try
            {
                this.RequireRecalculatePar = false;
                flag2 = this.InternalLoadData(xdata);
            }
            finally
            {
                this.RequireRecalculatePar = true;
                this.RecalculateTreePar();
            }
            return flag2;
        }

        public bool LoadData(byte[] byteData)
        {
            bool flag = true;
            try
            {
                MemoryStream xdata = new MemoryStream(byteData);
                xdata.Position = 0L;
                flag = this.LoadData(xdata);
                xdata.Close();
            }
            catch
            {
                flag = false;
            }
            return flag;
        }

        protected void RecalculateTreePar()
        {
            if (this.requireRecalculatePar)
            {
                Asn1Node parentNode = this;
                while (parentNode.ParentNode != null)
                {
                    parentNode = parentNode.ParentNode;
                }
                ResetBranchDataLength(parentNode);
                parentNode.dataOffset = 0L;
                parentNode.deepness = 0L;
                long subOffset = (parentNode.dataOffset + 1L) + parentNode.lengthFieldBytes;
                this.ResetChildNodePar(parentNode, subOffset);
            }
        }

        public Asn1Node RemoveChild(Asn1Node node)
        {
            int index = this.childNodeList.IndexOf(node);
            return this.RemoveChild(index);
        }

        public Asn1Node RemoveChild(int index)
        {
            Asn1Node node = null;
            if (index < (this.childNodeList.Count - 1))
            {
                node = (Asn1Node) this.childNodeList[index + 1];
            }
            this.childNodeList.RemoveAt(index);
            if (node == null)
            {
                if (this.childNodeList.Count > 0)
                {
                    node = (Asn1Node) this.childNodeList[this.childNodeList.Count - 1];
                }
                else
                {
                    node = this;
                }
            }
            this.RecalculateTreePar();
            return node;
        }

        protected static long ResetBranchDataLength(Asn1Node node)
        {
            long num2 = 0L;
            if (node.ChildNodeCount < 1L)
            {
                if (node.data != null)
                {
                    num2 += node.data.Length;
                }
            }
            else
            {
                for (int i = 0; i < node.ChildNodeCount; i++)
                {
                    num2 += ResetBranchDataLength(node.GetChildNode(i));
                }
            }
            node.dataLength = num2;
            if (node.tag == 3)
            {
                node.dataLength += 1L;
            }
            ResetDataLengthFieldWidth(node);
            return ((node.dataLength + 1L) + node.lengthFieldBytes);
        }

        protected static void ResetDataLengthFieldWidth(Asn1Node node)
        {
            MemoryStream xdata = new MemoryStream();
            Asn1Util.DERLengthEncode(xdata, (ulong) node.dataLength);
            node.lengthFieldBytes = xdata.Length;
            xdata.Close();
        }

        protected void ResetChildNodePar(Asn1Node xNode, long subOffset)
        {
            if (xNode.tag == 3)
            {
                subOffset += 1L;
            }
            for (int i = 0; i < xNode.ChildNodeCount; i++)
            {
                Asn1Node childNode = xNode.GetChildNode(i);
                childNode.parentNode = xNode;
                childNode.dataOffset = subOffset;
                childNode.deepness = xNode.deepness + 1L;
                childNode.path = xNode.path + '/' + i.ToString();
                subOffset += 1L + childNode.lengthFieldBytes;
                this.ResetChildNodePar(childNode, subOffset);
                subOffset += childNode.dataLength;
            }
        }

        public bool SaveData(Stream xdata)
        {
            bool flag = true;
            long childNodeCount = this.ChildNodeCount;
            xdata.WriteByte(this.tag);
            Asn1Util.DERLengthEncode(xdata, (ulong) this.dataLength);
            if (this.tag == 3)
            {
                xdata.WriteByte(this.unusedBits);
            }
            if (childNodeCount == 0L)
            {
                if (this.data != null)
                {
                    xdata.Write(this.data, 0, this.data.Length);
                }
                return flag;
            }
            for (int i = 0; i < childNodeCount; i++)
            {
                flag = this.GetChildNode(i).SaveData(xdata);
            }
            return flag;
        }

        protected void SetData(byte[] xdata)
        {
            if (this.childNodeList.Count > 0)
            {
                throw new Exception("Constructed node can't hold simple data.");
            }
            this.data = xdata;
            if (this.data != null)
            {
                this.dataLength = this.data.Length;
            }
            else
            {
                this.dataLength = 0L;
            }
            this.RecalculateTreePar();
        }

        public byte[] Data
        {
            get
            {
                MemoryStream xdata = new MemoryStream();
                long childNodeCount = this.ChildNodeCount;
                if (childNodeCount == 0L)
                {
                    if (this.data != null)
                    {
                        xdata.Write(this.data, 0, this.data.Length);
                    }
                }
                else
                {
                    for (int i = 0; i < childNodeCount; i++)
                    {
                        this.GetChildNode(i).SaveData(xdata);
                    }
                }
                byte[] buffer = new byte[xdata.Length];
                xdata.Position = 0L;
                xdata.Read(buffer, 0, (int) xdata.Length);
                xdata.Close();
                return buffer;
            }
            set
            {
                this.SetData(value);
            }
        }

        public long DataLength
        {
            get
            {
                return this.dataLength;
            }
        }

        public long DataOffset
        {
            get
            {
                return this.dataOffset;
            }
        }

        public long Deepness
        {
            get
            {
                return this.deepness;
            }
        }

        public long ChildNodeCount
        {
            get
            {
                return (long) this.childNodeList.Count;
            }
        }

        public bool IsEmptyData
        {
            get
            {
                return ((this.data == null) || (this.data.Length < 1));
            }
        }

        public bool IsIndefiniteLength
        {
            get
            {
                return this.isIndefiniteLength;
            }
            set
            {
                this.isIndefiniteLength = value;
            }
        }

        public long LengthFieldBytes
        {
            get
            {
                return this.lengthFieldBytes;
            }
        }

        public Asn1Node ParentNode
        {
            get
            {
                return this.parentNode;
            }
        }

        public bool ParseEncapsulatedData
        {
            get
            {
                return this.parseEncapsulatedData;
            }
            set
            {
                if (this.parseEncapsulatedData != value)
                {
                    byte[] data = this.Data;
                    this.parseEncapsulatedData = value;
                    this.ClearAll();
                    if (((this.tag & 0x20) == 0) && !this.parseEncapsulatedData)
                    {
                        this.Data = data;
                    }
                    else
                    {
                        MemoryStream xdata = new MemoryStream(data);
                        xdata.Position = 0L;
                        bool flag = true;
                        while (xdata.Position < xdata.Length)
                        {
                            Asn1Node node = new Asn1Node();
                            node.ParseEncapsulatedData = this.parseEncapsulatedData;
                            if (!node.LoadData(xdata))
                            {
                                this.ClearAll();
                                flag = false;
                                break;
                            }
                            this.AddChild(node);
                        }
                        if (!flag)
                        {
                            this.Data = data;
                        }
                    }
                }
            }
        }

        public string Path
        {
            get
            {
                return this.path;
            }
        }

        protected bool RequireRecalculatePar
        {
            get
            {
                return this.requireRecalculatePar;
            }
            set
            {
                this.requireRecalculatePar = value;
            }
        }

        public byte Tag
        {
            get
            {
                return this.tag;
            }
            set
            {
                this.tag = value;
            }
        }

        public string TagName
        {
            get
            {
                return Asn1Util.GetTagName(this.tag);
            }
        }

        public byte UnusedBits
        {
            get
            {
                return this.unusedBits;
            }
            set
            {
                this.unusedBits = value;
            }
        }

        public class TagTextMask
        {
            public const uint SHOW_DATA = 2;
            public const uint SHOW_OFFSET = 1;
            public const uint SHOW_PATH = 0x10;
            public const uint SHOW_TAG_NUMBER = 8;
            public const uint USE_HEX_OFFSET = 4;
        }
    }
}


namespace LipingShare.LCLib.Asn1Processor
{
    using System;
    using System.IO;

    public class Asn1Parser
    {
        private byte[] rawData;
        private Asn1Node rootNode = new Asn1Node();

        public Asn1Node GetNodeByOid(string oid)
        {
            return Asn1Node.GetDecendantNodeByOid(oid, this.rootNode);
        }

        public Asn1Node GetNodeByPath(string nodePath)
        {
            return this.rootNode.GetDescendantNodeByPath(nodePath);
        }

        public static string GetNodeText(Asn1Node node, int lineLen)
        {
            return (GetNodeTextHeader(lineLen) + node.GetText(node, lineLen));
        }

        public static string GetNodeTextHeader(int lineLen)
        {
            return (string.Format("Offset| Len  |LenByte|\r\n", new object[0]) + "======+======+=======+" + Asn1Util.GenStr(lineLen + 10, '=') + "\r\n");
        }

        public void LoadData(Stream stream)
        {
            stream.Position = 0L;
            if (!this.rootNode.LoadData(stream))
            {
                throw new Exception("Failed to load data.");
            }
            this.rawData = new byte[stream.Length];
            stream.Position = 0L;
            stream.Read(this.rawData, 0, this.rawData.Length);
        }

        public void LoadData(string fileName)
        {
            FileStream stream = new FileStream(fileName, FileMode.Open);
            this.rawData = new byte[stream.Length];
            stream.Read(this.rawData, 0, (int) stream.Length);
            stream.Close();
            MemoryStream stream2 = new MemoryStream(this.rawData);
            this.LoadData(stream2);
        }

        public void LoadPemData(string fileName)
        {
            FileStream stream = new FileStream(fileName, FileMode.Open);
            byte[] buffer = new byte[stream.Length];
            stream.Read(buffer, 0, buffer.Length);
            stream.Close();
            string pemStr = Asn1Util.BytesToString(buffer);
            if (!Asn1Util.IsPemFormated(pemStr))
            {
                throw new Exception("It is a invalid PEM file: " + fileName);
            }
            Stream stream2 = Asn1Util.PemToStream(pemStr);
            stream2.Position = 0L;
            this.LoadData(stream2);
        }

        public void SaveData(string fileName)
        {
            FileStream xdata = new FileStream(fileName, FileMode.Create);
            this.rootNode.SaveData(xdata);
            xdata.Close();
        }

        public override string ToString()
        {
            return GetNodeText(this.rootNode, 100);
        }

        private bool ParseEncapsulatedData
        {
            get
            {
                return this.rootNode.ParseEncapsulatedData;
            }
            set
            {
                this.rootNode.ParseEncapsulatedData = value;
            }
        }

        public byte[] RawData
        {
            get
            {
                return this.rawData;
            }
        }

        public Asn1Node RootNode
        {
            get
            {
                return this.rootNode;
            }
        }
    }
}


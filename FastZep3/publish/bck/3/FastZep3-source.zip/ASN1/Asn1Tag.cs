namespace LipingShare.LCLib.Asn1Processor
{
    using System;

    public class Asn1Tag
    {
        public const byte BIT_STRING = 3;
        public const byte BMPSTRING = 30;
        public const byte BOOLEAN = 1;
        public const byte ENUMERATED = 10;
        public const byte EXTERNAL = 8;
        public const byte GENERAL_STRING = 0x1b;
        public const byte GENERALIZED_TIME = 0x18;
        public const byte GRAPHIC_STRING = 0x19;
        public const byte IA5_STRING = 0x16;
        public const byte INTEGER = 2;
        public const byte NUMERIC_STRING = 0x12;
        public const byte OBJECT_DESCRIPTOR = 7;
        public const byte OBJECT_IDENTIFIER = 6;
        public const byte OCTET_STRING = 4;
        public const byte PRINTABLE_STRING = 0x13;
        public const byte REAL = 9;
        public const byte RELATIVE_OID = 13;
        public const byte SEQUENCE = 0x10;
        public const byte SET = 0x11;
        public const byte T61_STRING = 20;
        public const byte TAG_MASK = 0x1f;
        public const byte TAG_NULL = 5;
        public const byte UNIVERSAL_STRING = 0x1c;
        public const byte UTC_TIME = 0x17;
        public const byte UTF8_STRING = 12;
        public const byte VIDEOTEXT_STRING = 0x15;
        public const byte VISIBLE_STRING = 0x1a;
        public const byte CONTEXT_SPECIFIC = 0xA4;

    }
}


namespace LipingShare.LCLib.Asn1Processor
{
    using System;

    public class Asn1TagClasses
    {
        public const byte APPLICATION = 0x40;
        public const byte CLASS_MASK = 0xc0;
        public const byte CONSTRUCTED = 0x20;
        public const byte CONTEXT_SPECIFIC = 0x80;
        public const byte PRIVATE = 0xc0;
        public const byte UNIVERSAL = 0;
    }
}


namespace LipingShare.LCLib.Asn1Processor
{
    using System;
    using System.Windows.Forms;

    public class Asn1TreeNode : TreeNode
    {
        private Asn1Node asn1Node;

        private Asn1TreeNode()
        {
            this.asn1Node = new Asn1Node();
        }

        public Asn1TreeNode(Asn1Node node, uint mask)
        {
            this.asn1Node = new Asn1Node();
            this.asn1Node = node;
            base.Text = node.GetLabel(mask);
        }

        public static void AddSubNode(Asn1TreeNode node, uint mask, TreeView treeView)
        {
            for (int i = 0; i < node.ANode.ChildNodeCount; i++)
            {
                Asn1TreeNode node2 = new Asn1TreeNode();
                node2.asn1Node = node.ANode.GetChildNode(i);
                node2.Text = node2.ANode.GetLabel(mask);
                node.Nodes.Add(node2);
                node.Expand();
                if (treeView != null)
                {
                    treeView.SelectedNode = node;
                }
                AddSubNode(node2, mask, treeView);
            }
        }
        /**
         * Added by LS
         * 
         */
        public static Asn1TreeNode AddSubNode(Asn1TreeNode node, uint mask)
        {

            Asn1TreeNode node2 = new Asn1TreeNode();
            node2.Text = node2.ANode.GetLabel(mask);
            node.Nodes.Add(node2);
            node.Expand();
            return node2;
            
        }

        public static TreeNode SearchTreeNode(TreeNode treeNode, Asn1Node node)
        {
            TreeNode node2 = null;
            if (node != null)
            {
                if (((Asn1TreeNode) treeNode).ANode == node)
                {
                    return treeNode;
                }
                for (int i = 0; i < treeNode.Nodes.Count; i++)
                {
                    if (((Asn1TreeNode) treeNode.Nodes[i]).ANode == node)
                    {
                        return treeNode.Nodes[i];
                    }
                    node2 = SearchTreeNode(treeNode.Nodes[i], node);
                    if (node2 != null)
                    {
                        return node2;
                    }
                }
            }
            return node2;
        }

        public Asn1Node ANode
        {
            get
            {
                return this.asn1Node;
            }
        }
    }
}


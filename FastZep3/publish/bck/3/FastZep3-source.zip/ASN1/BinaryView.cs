namespace LipingShare.LCLib.Asn1Processor
{
    using System;
    using System.Text;

    public class BinaryView
    {
        private int dataWidth;
        private int hexWidth;
        private int offsetWidth;
        private int totalWidth;

        public BinaryView()
        {
            this.offsetWidth = 6;
            this.dataWidth = 0x10;
            this.CalculatePar();
        }

        public BinaryView(int offsetWidth, int dataWidth)
        {
            this.offsetWidth = 6;
            this.dataWidth = 0x10;
            this.SetPar(offsetWidth, dataWidth);
        }

        protected void CalculatePar()
        {
            this.totalWidth = ((((this.offsetWidth + 2) + (this.dataWidth * 3)) + ((this.dataWidth / 8) - 1)) + 1) + this.dataWidth;
            this.hexWidth = this.totalWidth - this.dataWidth;
        }

        public string GenerateText(byte[] data)
        {
            return GetBinaryViewText(data, this.offsetWidth, this.dataWidth);
        }

        public static string GetBinaryViewText(byte[] data, int offsetWidth, int dataWidth)
        {
            string format = "{0:X" + offsetWidth + "}  ";
            int num4 = 0;
            int num5 = 0;
            int num6 = ((((offsetWidth + 2) + (dataWidth * 3)) + ((dataWidth / 8) - 1)) + 1) + dataWidth;
            int totalWidth = num6 - dataWidth;
            string str4 = "";
            StringBuilder builder = new StringBuilder();
            string str5 = "{0,-" + num6 + "}\r\n";
            num5 = 0;
            while (num5 < data.Length)
            {
                str4 = string.Format(format, num4++ * dataWidth);
                int num2 = num5;
                int index = 0;
                while (index < dataWidth)
                {
                    str4 = str4 + string.Format("{0:X2} ", data[num5++]);
                    if (num5 >= data.Length)
                    {
                        break;
                    }
                    if (((((index + 1) % 8) == 0) && (index != 0)) && ((index + 1) < dataWidth))
                    {
                        str4 = str4 + " ";
                    }
                    index++;
                }
                str4 = str4 + " ";
                int num3 = num5;
                str4 = str4.PadRight(totalWidth, ' ');
                for (index = num2; index < num3; index++)
                {
                    if ((data[index] < 0x20) || (data[index] > 0x80))
                    {
                        str4 = str4 + '.';
                    }
                    else
                    {
                        str4 = str4 + ((char) data[index]);
                    }
                }
                builder.AppendFormat(str5, str4);
            }
            return builder.ToString();
        }

        public void GetLocation(int byteOffset, ByteLocation loc)
        {
            int num = byteOffset - ((byteOffset / this.dataWidth) * this.dataWidth);
            int num2 = byteOffset / this.dataWidth;
            int num3 = (this.offsetWidth + 2) + (num * 3);
            int num4 = 3;
            int num5 = ((num2 * this.totalWidth) + num2) + num3;
            int num6 = this.hexWidth + num;
            int num7 = ((num2 * this.totalWidth) + num2) + num6;
            int num8 = 1;
            loc.hexOffset = num5;
            loc.hexColLen = num4;
            loc.line = num2;
            loc.chOffset = num7;
            loc.chColLen = num8;
        }

        public void SetPar(int offsetWidth, int dataWidth)
        {
            this.offsetWidth = offsetWidth;
            this.dataWidth = dataWidth;
            this.CalculatePar();
        }

        public int DataWidth
        {
            get
            {
                return this.dataWidth;
            }
        }

        public int HexWidth
        {
            get
            {
                return this.hexWidth;
            }
        }

        public int OffsetWidth
        {
            get
            {
                return this.offsetWidth;
            }
        }

        public int TotalWidth
        {
            get
            {
                return this.totalWidth;
            }
        }
    }
}


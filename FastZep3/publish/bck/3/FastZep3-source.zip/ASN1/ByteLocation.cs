namespace LipingShare.LCLib.Asn1Processor
{
    using System;

    public class ByteLocation
    {
        public int hexColLen = 3;
        public int hexOffset;
        public int chColLen = 1;
        public int chOffset;
        public int line;
    }
}


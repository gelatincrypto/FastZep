namespace LipingShare.LCLib.Asn1Processor
{
    using System;
    using System.IO;

    public interface IAsn1Node
    {
        void AddChild(Asn1Node xdata);
        void ClearAll();
        Asn1Node Clone();
        string GetDataStr(bool pureHexMode);
        Asn1Node GetDescendantNodeByPath(string nodePath);
        Asn1Node GetChildNode(int index);
        string GetLabel(uint mask);
        string GetText(Asn1Node startNode, int lineLen);
        int InsertChild(Asn1Node xdata, Asn1Node indexNode);
        int InsertChild(Asn1Node xdata, int index);
        int InsertChildAfter(Asn1Node xdata, Asn1Node indexNode);
        int InsertChildAfter(Asn1Node xdata, int index);
        bool LoadData(Stream xdata);
        Asn1Node RemoveChild(Asn1Node node);
        Asn1Node RemoveChild(int index);
        bool SaveData(Stream xdata);

        byte[] Data { get; set; }

        long DataLength { get; }

        long DataOffset { get; }

        long Deepness { get; }

        long ChildNodeCount { get; }

        long LengthFieldBytes { get; }

        Asn1Node ParentNode { get; }

        bool ParseEncapsulatedData { get; set; }

        string Path { get; }

        byte Tag { get; set; }

        string TagName { get; }

        byte UnusedBits { get; }
    }
}


namespace LipingShare.LCLib.Asn1Processor
{
    using System;

    public class NamespaceDoc
    {
        private NamespaceDoc()
        {
        }
    }
}


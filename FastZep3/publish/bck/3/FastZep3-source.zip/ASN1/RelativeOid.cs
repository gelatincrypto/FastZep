namespace LipingShare.LCLib.Asn1Processor
{
    using System;
    using System.IO;

    public class RelativeOid : Oid
    {
        public override string Decode(Stream bt)
        {
            string str = "";
            ulong v = 0L;
            bool flag = true;
            while (bt.Position < bt.Length)
            {
                try
                {
                    base.DecodeValue(bt, ref v);
                    if (flag)
                    {
                        str = v.ToString();
                        flag = false;
                    }
                    else
                    {
                        str = str + "." + v.ToString();
                    }
                    continue;
                }
                catch (Exception exception)
                {
                    throw new Exception("Failed to decode OID value: " + exception.Message);
                }
            }
            return str;
        }

        public override void Encode(Stream bt, string oidStr)
        {
            string[] strArray = oidStr.Split(new char[] { '.' });
            ulong[] numArray = new ulong[strArray.Length];
            for (int i = 0; i < strArray.Length; i++)
            {
                numArray[i] = Convert.ToUInt64(strArray[i]);
            }
            for (int j = 0; j < numArray.Length; j++)
            {
                base.EncodeValue(bt, numArray[j]);
            }
        }
    }
}


namespace LipingShare.LCLib.Asn1Processor
{
    using System;

    public class VersionInfo
    {
        private static string author = "Liping Dai";
        private static string contactInfo = "LipingShare@yahoo.com";
        private static string copyrightStr = "Copyright \x00a9 2003,2004,2005,2007,2008 Liping Dai. All rights reserved.";
        private static string releaseDate = "September 29, 2008";
        private static string updateUrl = "http://www.lipingshare.com/Asn1Editor";
        private static string versionStr = "V2008.09.29 - 1.0.20";

        public static string Author
        {
            get
            {
                return author;
            }
        }

        public static string ContactInfo
        {
            get
            {
                return contactInfo;
            }
        }

        public static string CopyrightStr
        {
            get
            {
                return copyrightStr;
            }
        }

        public static string ReleaseDate
        {
            get
            {
                return releaseDate;
            }
        }

        public static string UpdateUrl
        {
            get
            {
                return updateUrl;
            }
        }

        public static string VersionStr
        {
            get
            {
                return versionStr;
            }
        }
    }
}


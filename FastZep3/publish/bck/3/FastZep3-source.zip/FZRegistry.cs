﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;

namespace FastZep2
{
    class FZRegistry
    {
        public static string get(string key)
        {
            RegistryKey key1 = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\FastZep\FastZep3");
            if (key1 == null)
            {
                Registry.CurrentUser.CreateSubKey(@"SOFTWARE\FastZep\FastZep3");
                key1 = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\FastZep\FastZep3", true);
                if (key1 == null) throw new Exception("No key in Registry");
            }
            object obj = key1.GetValue(key);
            if (obj == null) throw new Exception("No key in Registry");
            return obj.ToString();
        }
        public static bool set(string key, string value)
        {
            RegistryKey key1 = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\FastZep\FastZep3", true);
            if (key1 == null)
            {
                Registry.CurrentUser.CreateSubKey(@"SOFTWARE\FastZep\FastZep3");
                key1 = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\FastZep\FastZep3", true);
                if (key1 == null) throw new Exception("No key in Registry");
            }

            key1.SetValue(key, value);
            return true;
        }

    }
}
